$(function(){
   
    function comment1(){
        $('.comment button').click(function(){
            var val = $(this).siblings('input').val();
            var children = comment(val);
            $(this).parents().siblings('p.text').after(children)
        })
    }
    function comment(text){
        return `<div class="mycomment mt-3 mb-3 d-flex align-items-center">
        <div class="circle1">
          <img src="/assets/img/6.png" width="50" alt="">
         
        </div>
        <p>${text}</p>
      </div>`
    }
    var article = '';
    var str = '';
    $('.submit').click(function(){
        article = $('textarea').val();
        str =`  <div class="input border-box mb-2 mr-2">
        <div class="d-flex align-items-center">
          <div class="circle">
            <img src="/assets/img/6.png" width="50" alt="">
          </div>
          <div class="name ml-1">
            <p>我
            </p>
            <p>刚刚发表</p>
          </div>      
        </div>
        <p class="text">${article}</p>     
      
        <div class="comment collapse" id="demo">
          <div class="d-flex align-items-center">
            <div class="circle">
              <img src="/assets/img/6.png" width="50" alt="">
              
            </div>
            <input type="text" placeholder="评论">
            <button>评论</button>
          </div>
      </div>
      </div`
      $('.pub').before(str);
      comment1();
      $('textarea').val('')
    })
    $('.index').click(function(){
      window.location = 'index.html'
  })
})