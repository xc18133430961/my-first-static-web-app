$(function(){
    function comment1(){
        $('.comment button').click(function(){
            var val = $(this).siblings('input').val();
            if(val==''){
                return
            }
            var children = comment(val);
            $(this).parents().siblings('p.text').after(children)
        })
    }
    comment1()
    function comment(text){
        return `<div class="mycomment mb-2 mt-3 d-flex align-items-center">
        <div class="circle1">
          <img src="/assets/img/6.png" width="50" alt="">
         
        </div>
        <p>${text}</p>
      </div>`
    }
    $('.publish').click(function(){
        window.location = '/index/index/publish'
    })
    var top = $('.settop');
    top.click(function(){
        $(this).parents('.input').addClass('order-1 active').removeClass('order-3').siblings().addClass('order-3').removeClass('order-1 active')
        
    })
    console.log(6);
    $('.togglelist p').eq(0).click(function(){
        window.location = '/index/index'
    })
    $('.togglelist p').eq(1).click(function(){
        console.log(6);
        window.location = '/index/index/concern'
    })
    $('.togglelist p').eq(2).click(function(){
        window.location = '/index/index/follower'
    })
    $('.togglelist p').eq(3).click(function(){
        window.location = '/index/index/message'
    })
    
})