<?php

namespace app\common\model;

use think\Model;

class Article extends Model
{

    // 表名
    protected $name = 'article';
    // 自动写入时间戳字段
    // 追加属性
    protected $append = [
    ];

}
