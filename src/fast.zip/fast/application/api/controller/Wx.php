<?php

namespace app\api\controller;

use app\common\controller\Api;
use think\Db;
use think\Config;
use think\Session;
use addons\epay\controller\Index;
/**
 * 微信支付
 */
class Wx extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];


    /**
     * 小程序支付
     * @param $id 订单id
     * @param $openid 订单id
     * @return void
     */
    public function pay()
    {
        $pay = new Index;
        return $pay->pay();
    }


}
