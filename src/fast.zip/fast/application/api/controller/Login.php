<?php

namespace app\api\controller;

use app\admin\model\Category;
use app\admin\model\Fangjian;
use app\admin\model\Gonggao;
use app\admin\model\Jiameng;
use app\admin\model\Order;
use app\admin\model\Pinglun;
use app\admin\model\Renzheng;
use app\common\controller\Api;
use think\Db;
use think\Config;
use think\Session;
use addons\epay\controller\Index;
use addons\third\library\Wechat;
use addons\third\controller\Index as wxDenglu;
/**
 * 小程序登录
 */
class Login extends Api
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    /**
     * 获取授权
     * @return void
     */
    public function connect()
    {
        $wxModel = new wxDenglu();

        return $wxModel->connect('wechat');
    }


    /**
     * 获取授权
     * @param string $code 传一个code
     */
    public function callback()
    {

        $wxModel = new wxDenglu();
        return $wxModel->callback();
    }

    /**
     * 小程序登录
     *
     * @param string $code  code
     * @param string $nickName  nickName
     * @param string $avatar  头像
     */
    public function loginInfo(){
//        接收前台传来的值
        $code=input('code');
        $nickName=input('nickName');
        $avatar = input('avatar');

//        判断是否为空
        if (empty($code)||empty($nickName)){
            return json(['code'=>0,'data'=>'','mag'=>'参数不正确']);
        }
        $appID = 'wxd9ae69f183ed1214';
        $appSecret = '9830f4c61095877879c9d7d5126e03b7';
//        请求地址
        $url = "https://api.weixin.qq.com/sns/jscode2session?appid=".$appID."&secret=".$appSecret."&js_code=".$code."&grant_type=authorization_code";
        $res = $this->getUrl($url);

        $arr=[
            'username'=>$nickName,
            'nickname'=>$nickName,
            'session_key'=>$res['session_key'],
            'openid'=>$res['openid'],
            'code'=>$code,
            'avatar' => $avatar
        ];
        $model= new \app\admin\model\User();
        $data = $model->where('openid',$res['openid'])->find();
        if (!empty($data)){
            $model->where('openid',$res['openid'])->update(['session_key'=>$res['session_key']]);
        }else{
            $model->save($arr);
        }
        $data = $model->where('id',$data->id)->find();

        Session::set("user", $data);
        $this->success('请求成功', $data);
    }



    //        getUrl是在common中封装的，封装样式如下
    public function getUrl($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($output,true);
        return $output;
    }



}
