<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\Ems;
use app\common\library\Sms;
use fast\Random;
use think\Config;
use think\Session;
use think\Validate;
use think\Cache;
/**
 * 会员接口
 */
class User extends Api
{
    protected $noNeedLogin = ['login','lslogin', 'get_access_token', 'mobilelogin', 'register', 'resetpwd', 'changeemail', 'changemobile', 'third','profile','userUpdate','getUrl', 'loginInfo', 'user_phone'];
    protected $noNeedRight = '*';
    public $AppId = 'wxe9459e02b5c8d733';
    public $Secret = '61da4bfbd7c346e1894d58e7be23d951';


    public function _initialize()
    {
        parent::_initialize();

        if (!Config::get('fastadmin.usercenter')) {
            $this->error(__('User center already closed'));
        }

    }

    /**
     * 模拟登录
     * @param string $id
     * @return void
     */
    public function lslogin()
    {
        $id = input('id');
        $this->auth->direct($id);
        $data = ['userinfo' => $this->auth->getUserinfo()];
        $data['userinfo']['avatar'] = http($data['userinfo']['avatar']);
        $this->success(__('Logged in successful'), $data);
    }

    /**
     * 获取用户手机号
     * @param string $code
     * @param string $user_id
     *
     */
    public function user_phone(){
        //获取前端传过来的code，如果前端不知道code是啥，就刁他。
        $user_id = input('user_id');
        $code = input('code');
        if(!isset($code) || empty($code)){
            $this->error('非法请求');
        }

        //获取accesstoken
        $accessToken = $this->get_access_token();

        //请求地址
        $url = 'https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token='.$accessToken;
        //前端传递的code
//        $code = $post['code'];
        //组成数组
        $data=[
            'code'=>$code,
        ];

        //这里要把传递的参数给转成json，不然小程序接口会报数据类型错误。
        $result = json_decode(curl_post_https($url,json_encode($data)),true);
        //开始判断获取是否成功
        if($result['errmsg'] == 0){
            //获取成功
            $phoen = $result['phone_info']['phoneNumber'];
//            $return['smg'] = '获取手机号成功！';
//            $return['code'] = 200;
            $return['phone'] = $phoen;
            //把手机号返回给前端，或者自己进行存储。看需求
            //Db::name('user')->add();
            \app\admin\model\User::where('id', $user_id)->update(['mobile' => $phoen]);
//            return json_encode($return);
            $this->success('获取成功', $return);

        }else{
//            $return['smg'] = '获取手机号失败！';
//            $return['code'] = 201;
//            return json_encode($return);
            $this->error('获取失败');

        }


    }


    //获取小程序二维码的token
    public function get_access_token()
    {
        //先判断缓存里面的access_token过期了没有
        if(Cache::get('access_token')){
            //没过期直接拿出来用
            $a = Cache::get('access_token');
            return $a;
        }else{
            //过期了就重新获取
            $appid = $this->AppId;
            $secret = $this->Secret;
            $url = "https://api.weixin.qq.com/cgi-bin/token? grant_type=client_credential&appid=$appid&secret=$secret";
            //请求接口，获取accesstoken
            $user_obj = curlHttp($url);
            //然后将accesstoken存入缓存里面，官方过期时间7200秒，缓存里面可以过期的早一点，自己把控
            Cache::set('access_token',$user_obj['access_token'],7100);

            return Cache::get('access_token');
        }
    }



    /**
     * 小程序登录
     *
     * @param string $code  code
     * @param string $nickName  nickName
     * @param string $avatar  头像
     * @param string $pid  推荐人id
     */
    public function loginInfo(){
//        接收前台传来的值
        $code=input('code');
        $nickName=input('nickName');
        $avatar = input('avatar');
        $pid = input('pid');

//        判断是否为空
        if (empty($code)||empty($nickName)){
            return json(['code'=>0,'data'=>'','mag'=>'参数不正确']);
        }
        $appID = 'wxe9459e02b5c8d733';
        $appSecret = '61da4bfbd7c346e1894d58e7be23d951';
//        请求地址
        $url = "https://api.weixin.qq.com/sns/jscode2session?appid=".$appID."&secret=".$appSecret."&js_code=".$code."&grant_type=authorization_code";
        $res = $this->getUrl($url);

        $arr=[
            'username'=>$nickName,
            'nickname'=>$nickName,
            'session_key'=>$res['session_key'],
            'openid'=>$res['openid'],
            'code'=>$code,
            'pid'=>$pid,
            'avatar' => $avatar,
            'group_id' => 1,
            'status' => 'normal'
        ];

        $username = Random::alnum(20);
        $password = Random::alnum(6);
        $domain = request()->host();


        $model= new \app\admin\model\User();
        $data = $model->where('openid',$res['openid'])->find();
        if (!empty($data)){
            $model->where('openid',$res['openid'])->update(['session_key'=>$res['session_key']]);
        }else{
//            $model->save($arr);
            $extend = [];
            $this->auth->register($nickName, $password, $username . '@' . $domain, '', $extend,$arr );

        }
        $data = $model->where('openid',$res['openid'])->find();

        $this->auth->direct($data['id']);
        $data['userinfo'] = $this->auth->getUserinfo();
//        $data['userinfo']['avatar'] = http($data['userinfo']['avatar']);
        $this->success('登录成功', $data);


//        Session::set("user", $data);
//        $this->success('请求成功', $data);
    }


    //        getUrl是在common中封装的，封装样式如下
    public function getUrl($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($output,true);
        return $output;
    }


    /**
     * 修改头像和名称
     * @param string $nickname 名称
     * @param string $avatar 头像
     * @param string $user_id 用户id
     */
    public function userUpdate()
    {
        $nickname = input('nickname');
        $avatar = input('avatar');
        $user_id = input('user_id');
        $user = \app\admin\model\User::get($user_id);

        if (!empty($avatar)) $data['avatar'] = $avatar;
        if (!empty($nickname)) $data['nickname'] = $nickname;

        $bool = \app\admin\model\User::where('id', $user_id)->update($data);

        if ($bool) {

            $this->success('修改成功');
        }
        $this->error('修改失败');
    }

    /**
     * 会员中心
     */
    public function index()
    {
        $this->success('', ['welcome' => $this->auth->nickname]);
    }

    /**
     * 会员登录
     *
     * @ApiMethod (POST)
     * @param string $account  账号
     * @param string $password 密码
     */
    public function login()
    {
        $account = $this->request->post('account');
        $password = $this->request->post('password');
        if (!$account || !$password) {
            $this->error(__('Invalid parameters'));
        }
        $ret = $this->auth->login($account, $password);
        if ($ret) {
            $data = ['userinfo' => $this->auth->getUserinfo()];
            $data['userinfo']['avatar'] = http($data['userinfo']['avatar']);
            $this->success(__('Logged in successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }

    /**
     * 手机验证码登录
     *
     * @ApiMethod (POST)
     * @param string $mobile  手机号
     * @param string $captcha 验证码
     */
    public function mobilelogin()
    {
        $mobile = $this->request->post('mobile');
        $captcha = $this->request->post('captcha');
        if (!$mobile || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        if (!Sms::check($mobile, $captcha, 'mobilelogin')) {
            $this->error(__('Captcha is incorrect'));
        }
        $user = \app\common\model\User::getByMobile($mobile);
        if ($user) {
            if ($user->status != 'normal') {
                $this->error(__('Account is locked'));
            }
            //如果已经有账号则直接登录
            $ret = $this->auth->direct($user->id);
        } else {
            $ret = $this->auth->register($mobile, Random::alnum(), '', $mobile, []);
        }
        if ($ret) {
            Sms::flush($mobile, 'mobilelogin');
            $data = ['userinfo' => $this->auth->getUserinfo()];
            $this->success(__('Logged in successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }

    /**
     * 注册会员
     *
     * @ApiMethod (POST)
     * @param string $username 用户名
     * @param string $password 密码
     * @param string $email    邮箱
     * @param string $mobile   手机号
     * @param string $code     验证码
     */
    public function register()
    {
        $username = $this->request->post('username');
        $password = $this->request->post('password');
        $email = $this->request->post('email');
        $mobile = $this->request->post('mobile');
        $code = $this->request->post('code');
        if (!$username || !$password) {
            $this->error(__('Invalid parameters'));
        }
        if ($email && !Validate::is($email, "email")) {
            $this->error(__('Email is incorrect'));
        }
        if ($mobile && !Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        $ret = Sms::check($mobile, $code, 'register');
        if (!$ret) {
            $this->error(__('Captcha is incorrect'));
        }
        $ret = $this->auth->register($username, $password, $email, $mobile, []);
        if ($ret) {
            $data = ['userinfo' => $this->auth->getUserinfo()];
            $this->success(__('Sign up successful'), $data);
        } else {
            $this->error($this->auth->getError());
        }
    }

    /**
     * 退出登录
     * @ApiMethod (POST)
     */
    public function logout()
    {
        if (!$this->request->isPost()) {
            $this->error(__('Invalid parameters'));
        }
        $this->auth->logout();
        $this->success(__('Logout successful'));
    }

    /**
     * 修改会员个人信息
     *
     * @ApiMethod (POST)
     * @param string $avatar   头像地址
     * @param string $username 用户名
     * @param string $nickname 昵称
     * @param string $bio      个人简介
     */
    public function profile()
    {
        $user = $this->auth->getUser();
        $username = $this->request->post('username');

        $nickname = $this->request->post('nickname');
        $bio = $this->request->post('bio');
        $avatar = $this->request->post('avatar', '', 'trim,strip_tags,htmlspecialchars');
        if ($username) {
            $exists = \app\common\model\User::where('username', $username)->where('id', '<>', $this->auth->id)->find();
            if ($exists) {
                $this->error(__('Username already exists'));
            }
            $user->username = $username;
        }
        if ($nickname) {
            $exists = \app\common\model\User::where('nickname', $nickname)->where('id', '<>', $this->auth->id)->find();
            if ($exists) {
                $this->error(__('Nickname already exists'));
            }
            $user->nickname = $nickname;
        }
        $user->bio = $bio;
        $user->avatar = $avatar;
        $user->save();
        $this->success();
    }

    /**
     * 修改邮箱
     *
     * @ApiMethod (POST)
     * @param string $email   邮箱
     * @param string $captcha 验证码
     */
    public function changeemail()
    {
        $user = $this->auth->getUser();
        $email = $this->request->post('email');
        $captcha = $this->request->post('captcha');
        if (!$email || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::is($email, "email")) {
            $this->error(__('Email is incorrect'));
        }
        if (\app\common\model\User::where('email', $email)->where('id', '<>', $user->id)->find()) {
            $this->error(__('Email already exists'));
        }
        $result = Ems::check($email, $captcha, 'changeemail');
        if (!$result) {
            $this->error(__('Captcha is incorrect'));
        }
        $verification = $user->verification;
        $verification->email = 1;
        $user->verification = $verification;
        $user->email = $email;
        $user->save();

        Ems::flush($email, 'changeemail');
        $this->success();
    }

    /**
     * 修改手机号
     *
     * @ApiMethod (POST)
     * @param string $mobile  手机号
     * @param string $captcha 验证码
     */
    public function changemobile()
    {
        $user = $this->auth->getUser();
        $mobile = $this->request->post('mobile');
        $captcha = $this->request->post('captcha');
        if (!$mobile || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error(__('Mobile is incorrect'));
        }
        if (\app\common\model\User::where('mobile', $mobile)->where('id', '<>', $user->id)->find()) {
            $this->error(__('Mobile already exists'));
        }
        $result = Sms::check($mobile, $captcha, 'changemobile');
        if (!$result) {
            $this->error(__('Captcha is incorrect'));
        }
        $verification = $user->verification;
        $verification->mobile = 1;
        $user->verification = $verification;
        $user->mobile = $mobile;
        $user->save();

        Sms::flush($mobile, 'changemobile');
        $this->success();
    }

    /**
     * 第三方登录
     *
     * @ApiMethod (POST)
     * @param string $platform 平台名称
     * @param string $code     Code码
     */
    public function third()
    {
        $url = url('user/index');
        $platform = $this->request->post("platform");
        $code = $this->request->post("code");
        $config = get_addon_config('third');
        if (!$config || !isset($config[$platform])) {
            $this->error(__('Invalid parameters'));
        }
        $app = new \addons\third\library\Application($config);
        //通过code换access_token和绑定会员
        $result = $app->{$platform}->getUserInfo(['code' => $code]);
        if ($result) {
            $loginret = \addons\third\library\Service::connect($platform, $result);
            if ($loginret) {
                $data = [
                    'userinfo'  => $this->auth->getUserinfo(),
                    'thirdinfo' => $result
                ];
                $this->success(__('Logged in successful'), $data);
            }
        }
        $this->error(__('Operation failed'), $url);
    }

    /**
     * 重置密码
     *
     * @ApiMethod (POST)
     * @param string $mobile      手机号
     * @param string $newpassword 新密码
     * @param string $captcha     验证码
     */
    public function resetpwd()
    {
        $type = $this->request->post("type");
        $mobile = $this->request->post("mobile");
        $email = $this->request->post("email");
        $newpassword = $this->request->post("newpassword");
        $captcha = $this->request->post("captcha");
        if (!$newpassword || !$captcha) {
            $this->error(__('Invalid parameters'));
        }
        //验证Token
        if (!Validate::make()->check(['newpassword' => $newpassword], ['newpassword' => 'require|regex:\S{6,30}'])) {
            $this->error(__('Password must be 6 to 30 characters'));
        }
        if ($type == 'mobile') {
            if (!Validate::regex($mobile, "^1\d{10}$")) {
                $this->error(__('Mobile is incorrect'));
            }
            $user = \app\common\model\User::getByMobile($mobile);
            if (!$user) {
                $this->error(__('User not found'));
            }
            $ret = Sms::check($mobile, $captcha, 'resetpwd');
            if (!$ret) {
                $this->error(__('Captcha is incorrect'));
            }
            Sms::flush($mobile, 'resetpwd');
        } else {
            if (!Validate::is($email, "email")) {
                $this->error(__('Email is incorrect'));
            }
            $user = \app\common\model\User::getByEmail($email);
            if (!$user) {
                $this->error(__('User not found'));
            }
            $ret = Ems::check($email, $captcha, 'resetpwd');
            if (!$ret) {
                $this->error(__('Captcha is incorrect'));
            }
            Ems::flush($email, 'resetpwd');
        }
        //模拟一次登录
        $this->auth->direct($user->id);
        $ret = $this->auth->changepwd($newpassword, '', true);
        if ($ret) {
            $this->success(__('Reset password successful'));
        } else {
            $this->error($this->auth->getError());
        }
    }
}
