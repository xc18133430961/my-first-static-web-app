<?php

namespace app\index\controller;

use app\common\controller\Frontend;
use think\Lang;
use think\Response;
use app\common\model\User;
use app\common\model\Article;



/**
 * Ajax异步请求接口
 * @internal
 */
class Ajax extends Frontend
{

    protected $noNeedLogin = ['lang', 'upload','echo','select','insert','delete','search','edit'];
    protected $noNeedRight = ['*'];
    protected $layout = '';

    /**
     * 加载语言包
     */
    public function select(){
        $id = input("id");
        $model = new User();
        $user = $model->where(array("id"=>$id))->select();
        return ['data'=>$user];
    }
    public function insert(){
        $val = $_GET['val'];
        $data = [
            'username'=>'Mr Birchoffical',
            'textarea'=>$val ,
            'pubtime'=>'2022-10-07',
        ];
        $model = new Article();
        $user = $model->insert($data);
        $user = $model->select();
        return ['data'=>$user];
    }
    public function delete(){
        $id = $_GET['id'];
        $model = new Article();
        $user = $model->where('id',$id)->update(['is_delete'=>1]);
    }
    public function edit(){
        $id = $_GET['id'];
        $val = $_GET['val'];
        $model = new Article();
        $user = $model->where('id',$id)->update(['textarea'=>$val]);
    }
    public function search(){
        $val = $_GET['val'];
        $model = new Article();
        $user = $model->whereLike('textarea',$val)->select();
        return ['data'=>$user];
    }
    
    public function echo(){
        $model = new Article();
        // $user = $model->where(array("id"=>$id))->find();
        $user = $model->where('is_delete',0)->select();

        return ['data'=>$user];
    }
    public function lang()
    {
        $header = ['Content-Type' => 'application/javascript'];
        if (!config('app_debug')) {
            $offset = 30 * 60 * 60 * 24; // 缓存一个月
            $header['Cache-Control'] = 'public';
            $header['Pragma'] = 'cache';
            $header['Expires'] = gmdate("D, d M Y H:i:s", time() + $offset) . " GMT";
        }

        $controllername = input("controllername");
        $this->loadlang($controllername);
        //强制输出JSON Object
        return jsonp(Lang::get(), 200, $header, ['json_encode_param' => JSON_FORCE_OBJECT | JSON_UNESCAPED_UNICODE]);
    }

    /**
     * 生成后缀图标
     */
    public function icon()
    {
        $suffix = $this->request->request("suffix");
        $suffix = $suffix ? $suffix : "FILE";
        $data = build_suffix_image($suffix);
        $header = ['Content-Type' => 'image/svg+xml'];
        $offset = 30 * 60 * 60 * 24; // 缓存一个月
        $header['Cache-Control'] = 'public';
        $header['Pragma'] = 'cache';
        $header['Expires'] = gmdate("D, d M Y H:i:s", time() + $offset) . " GMT";
        $response = Response::create($data, '', 200, $header);
        return $response;
    }

    /**
     * 上传文件
     */
    public function upload()
    {
        return action('api/common/upload');
    }

}
