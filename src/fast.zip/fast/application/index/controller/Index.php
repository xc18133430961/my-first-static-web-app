<?php

namespace app\index\controller;

use app\common\controller\Frontend;

class Index extends Frontend
{

    protected $noNeedLogin = '*';
    protected $noNeedRight = '*';
    protected $layout = '';

    public function index()
    {
        return $this->view->fetch();
    }
    
    public function concern()
    {
     
        return $this->view->fetch();
    }
    public function follower()
    {
     
        return $this->view->fetch();
    }
    public function message()
    {
     
        return $this->view->fetch();
    }
    public function publish()
    {
     
        return $this->view->fetch();
    }

}
