<?php

return [
    'Id'           => 'ID',
    'User_id'      => '会员ID',
    'Platform'     => '第三方应用',
    'Unionid'      => '第三方UnionID',
    'Openid'       => '第三方OpenID',
    'Openname'     => '第三方会员昵称',
    'Access_token' => 'AccessToken',
    'Expires_in'   => '有效期',
    'Createtime'   => '创建时间',
    'Updatetime'   => '更新时间',
    'Logintime'    => '登录时间',
    'Expiretime'   => '过期时间'
];
