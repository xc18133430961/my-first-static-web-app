<?php

return array(
    0 =>
        array(
            'name'    => 'customtext',
            'title'   => '自定义验证文字',
            'type'    => 'text',
            'content' =>
                array(),
            'value'   => '',
            'rule'    => 'required',
            'msg'     => '',
            'tip'     => '一行一个词语,单行中请勿出现重复文字<br>建议不超过6个汉字',
            'ok'      => '',
            'extend'  => '',
        ),
);
